function Para_Func()
{
	document.getElementById("target").innerHTML = "The Internet of Things (IoT) is the term which refers to the ever-growing network of physical objects with embedded sensors which can connect together via the internet allowing communication to occur between these objects and many other Internet-enabled devices and systems.";
}

function myFunction(arr)
{
	let out = "";
	let i;
	
	for(i = 0; i < arr.length; i++)
	{	
		out += '<a href="' + arr[i].url + '">' + '<img src=" ' + arr[i].img + '" width="75" height="75">' + '</a>';
	}
	
	document.getElementById("soc_med").innerHTML = out;
}

function mySearch()
{
	var x = document.getElementById("my_search").placeholder;
	document.getElementById("demo").innerHTML = x;
}