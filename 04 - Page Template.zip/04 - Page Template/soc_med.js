myFunction([
	{
		"display": "facebook",
		"url": "https://www.facebook.com",
		"img" : "icon_1.png"
	},
	{
		"display": "twitter",
		"url": "https://twitter.com",
		"img" : "icon_2.png"
	},
	{
		"display": "Linkedin",
		"url": "https://www.linkedin.com",
		"img" : "icon_3.png"
	},
	{
		"display": "Youtube",
		"url": "https://www.youtube.com",
		"img" : "icon_4.png"
	},
	{
		"display": "Pinterest",
		"url": "https://www.pinterest.co.uk",
		"img" : "icon_5.png"
	}
])